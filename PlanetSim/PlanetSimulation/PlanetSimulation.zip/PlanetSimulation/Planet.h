#ifndef _PLANET_H_
#define _PLANET_H_

#pragma once
#include <string>


class Planet
{
	
};



#endif // _PLANET_H_